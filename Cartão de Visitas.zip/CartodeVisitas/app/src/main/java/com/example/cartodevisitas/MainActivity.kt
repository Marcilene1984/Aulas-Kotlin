package com.example.cartodevisitas

import android.graphics.Color
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import android.text.method.LinkMovementMethod
import android.widget.TextView



class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        linksite()
        linkwhats()
        linkinsta()
    }

    fun linksite() {
        val linkTextView = findViewById<TextView>(R.id.sitelink)
        linkTextView.setMovementMethod(LinkMovementMethod.getInstance())
        linkTextView.setLinkTextColor(Color.WHITE)
    }
    fun linkwhats() {
        val linkTextView = findViewById<TextView>(R.id.whatslink)
        linkTextView.setMovementMethod(LinkMovementMethod.getInstance())
        linkTextView.setLinkTextColor(Color.WHITE)
    }
    fun linkinsta() {
        val linkTextView = findViewById<TextView>(R.id.instalink)
        linkTextView.setMovementMethod(LinkMovementMethod.getInstance())
        linkTextView.setLinkTextColor(Color.WHITE)
    }

}